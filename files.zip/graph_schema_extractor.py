"""
graph_schema_extractor.py

Purpose
-------
Manual-graph-design helper for the contract characterization platform.

Given one or more contract PDFs (e.g. the Honeywell CSP Subcontracting Plan,
or the DHS/EMS C-UAS IDIQ contract), this script:

  1. Extracts text page-by-page from each PDF.
  2. Sends each page (or a sliding window of pages, for context continuity)
     to GPT-4o-mini with a structured-extraction prompt.
  3. Asks the model to propose graph NODES (typed entities) and EDGES
     (typed relationships) it finds on that page, constrained to a seed
     ontology (so results stay comparable across pages/documents) but
     allowed to propose new types it thinks are missing (flagged separately).
  4. Aggregates + dedupes results across the whole document.
  5. Writes out:
       - <doc>_graph_candidates.json   (raw structured output per page)
       - <doc>_graph_summary.json      (deduped node/edge type counts +
                                          example instances, for you to
                                          eyeball before finalizing schema)

This is NOT meant to build the production graph. It's a reconnaissance
pass: run it over a handful of representative contracts, look at the
summary, and use it to lock in your Neo4j / graph schema (node labels,
relationship types, and which properties matter) before writing the
real ingestion pipeline.

Usage
-----
    export OPENAI_API_KEY=sk-...
    pip install openai pypdf --break-system-packages

    python graph_schema_extractor.py \
        --pdf "S0641225_Att.J2SmallBusinessSubcontractingPlan70RDA226D00000007EMSDefense.pdf" \
        --pdf "S0641225_70RDA226D00000007EMSDefenseTrack1FE.pdf" \
        --out ./graph_recon

Notes
-----
- Uses gpt-4o-mini via the Chat Completions API with JSON mode.
- Designed for text-native PDFs. If a PDF is scanned/image-only, swap
  the `extract_pages_text` function for a vision call (see
  `extract_pages_via_vision` stub at the bottom) that sends page images
  to gpt-4o-mini directly instead of extracted text.
"""

import argparse
import json
import os
import re
import time
from collections import defaultdict
from pathlib import Path

from openai import OpenAI
from pypdf import PdfReader

MODEL = "gpt-4o-mini"

# ---------------------------------------------------------------------------
# Seed ontology — this is a STARTING POINT based on a first read of the two
# sample contracts (Honeywell CSP + DHS C-UAS IDIQ). The model is told to
# prefer these types but may propose new ones under "suggested_new_types".
# ---------------------------------------------------------------------------
SEED_NODE_TYPES = [
    "Contract",            # e.g. "70RDA226D00000007", "CSP FY26 Agreement"
    "Party",                # Government agency or contractor entity
    "Person",               # Named individual (signatory, POC)
    "Role",                 # CO, COR, SBLO, PM, Key Personnel
    "Section",               # e.g. "Section C: Statement of Work", "10.4.2"
    "Requirement",           # A technical/compliance obligation
    "Standard",              # FAR, DFARS, NIST SP 800-53, MIL-STD-810H, etc.
    "Deliverable",            # Report/artifact the contractor must submit
    "Site",                    # CAGE code / UEI / facility address
    "BusinessCategory",         # SB, SDB, WOSB, HUBZone, VOSB, SDVOSB
    "Initiative",                 # Named strategic initiative / program
    "Milestone",                   # Dated step within an Initiative
    "PricingTrack",                 # e.g. "Track 1", "Track 2"
    "LaborCategory",                  # Named labor category w/ rate
    "Goal",                             # A numeric $/％ subcontracting goal
]

SEED_EDGE_TYPES = [
    "HAS_SECTION", "CONTAINS_REQUIREMENT", "REFERENCES_STANDARD",
    "HAS_DELIVERABLE", "DUE_TO", "SIGNED_BY", "HAS_ROLE",
    "COVERS_SITE", "HAS_GOAL", "RUNS_INITIATIVE", "HAS_MILESTONE",
    "SUPPORTS_CATEGORY", "PRICED_UNDER", "USES_LABOR_CATEGORY",
    "AMENDS", "REPORTS_TO",
]

SYSTEM_PROMPT = f"""You are helping design a knowledge graph schema for a
government contract intelligence platform. You will be given the text of
ONE page from a contract document (subcontracting plan, IDIQ contract, SOW,
etc.).

Extract graph-worthy entities and relationships found on this page ONLY.
Prefer these node types where they fit: {SEED_NODE_TYPES}
Prefer these relationship types where they fit: {SEED_EDGE_TYPES}

Rules:
- Only extract things actually stated on the page. Do not infer facts not present.
- Give each node a short canonical "name" and a "type" (from the seed list if possible).
- Give each edge a "source" name, "relation" (from seed list if possible), "target" name.
- Attach useful "properties" to nodes/edges when explicit in the text
  (dollar amounts, percentages, dates, CAGE/UEI codes, section numbers).
- If something important doesn't fit the seed types, still extract it, and
  list the type you used under "suggested_new_types" with a one-line reason.
- If the page has nothing graph-worthy (e.g. blank, pure boilerplate footer),
  return empty lists.

Return STRICT JSON with this shape:
{{
  "nodes": [{{"name": "...", "type": "...", "properties": {{}}}}],
  "edges": [{{"source": "...", "relation": "...", "target": "...", "properties": {{}}}}],
  "suggested_new_types": [{{"type": "...", "reason": "..."}}]
}}
"""


def extract_pages_text(pdf_path: str) -> list[str]:
    """Extract text per page from a text-native PDF."""
    reader = PdfReader(pdf_path)
    pages = []
    for page in reader.pages:
        text = page.extract_text() or ""
        pages.append(text)
    return pages


def call_model(client: OpenAI, page_text: str, page_num: int, doc_name: str) -> dict:
    if not page_text.strip():
        return {"nodes": [], "edges": [], "suggested_new_types": []}

    user_prompt = f"Document: {doc_name}\nPage: {page_num}\n\nPAGE TEXT:\n{page_text}"

    for attempt in range(3):
        try:
            resp = client.chat.completions.create(
                model=MODEL,
                temperature=0,
                response_format={"type": "json_object"},
                messages=[
                    {"role": "system", "content": SYSTEM_PROMPT},
                    {"role": "user", "content": user_prompt},
                ],
            )
            content = resp.choices[0].message.content
            return json.loads(content)
        except Exception as e:
            print(f"  [warn] page {page_num} attempt {attempt+1} failed: {e}")
            time.sleep(2 * (attempt + 1))
    return {"nodes": [], "edges": [], "suggested_new_types": []}


def process_pdf(client: OpenAI, pdf_path: str, out_dir: Path) -> None:
    doc_name = Path(pdf_path).stem
    print(f"\n=== Processing {doc_name} ===")
    pages = extract_pages_text(pdf_path)
    print(f"  {len(pages)} pages extracted")

    per_page_results = []
    for i, page_text in enumerate(pages, start=1):
        print(f"  -> page {i}/{len(pages)}")
        result = call_model(client, page_text, i, doc_name)
        result["page"] = i
        per_page_results.append(result)

    raw_out = out_dir / f"{doc_name}_graph_candidates.json"
    raw_out.write_text(json.dumps(per_page_results, indent=2))
    print(f"  Wrote raw candidates -> {raw_out}")

    summary = summarize(per_page_results)
    summary_out = out_dir / f"{doc_name}_graph_summary.json"
    summary_out.write_text(json.dumps(summary, indent=2))
    print(f"  Wrote summary -> {summary_out}")


def normalize_name(name: str) -> str:
    return re.sub(r"\s+", " ", name.strip().lower())


def summarize(per_page_results: list[dict]) -> dict:
    """Dedupe + count node/edge types so you can eyeball the emergent schema."""
    node_type_examples = defaultdict(set)
    edge_type_examples = defaultdict(set)
    suggested_types = defaultdict(set)

    node_count = defaultdict(int)
    edge_count = defaultdict(int)

    for page in per_page_results:
        for n in page.get("nodes", []):
            t = n.get("type", "Unknown")
            node_count[t] += 1
            if len(node_type_examples[t]) < 8:
                node_type_examples[t].add(n.get("name", ""))
        for e in page.get("edges", []):
            r = e.get("relation", "UNKNOWN")
            edge_count[r] += 1
            if len(edge_type_examples[r]) < 8:
                edge_type_examples[r].add(
                    f'{e.get("source","?")} -> {e.get("target","?")}'
                )
        for s in page.get("suggested_new_types", []):
            suggested_types[s.get("type", "?")].add(s.get("reason", ""))

    return {
        "node_type_counts": dict(sorted(node_count.items(), key=lambda x: -x[1])),
        "node_type_examples": {k: sorted(v) for k, v in node_type_examples.items()},
        "edge_type_counts": dict(sorted(edge_count.items(), key=lambda x: -x[1])),
        "edge_type_examples": {k: sorted(v) for k, v in edge_type_examples.items()},
        "suggested_new_types": {k: sorted(v) for k, v in suggested_types.items()},
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--pdf", action="append", required=True, help="Path to a contract PDF (repeatable)")
    parser.add_argument("--out", default="./graph_recon", help="Output directory")
    args = parser.parse_args()

    out_dir = Path(args.out)
    out_dir.mkdir(parents=True, exist_ok=True)

    api_key = os.environ.get("OPENAI_API_KEY")
    if not api_key:
        raise SystemExit("Set OPENAI_API_KEY in your environment first.")

    client = OpenAI(api_key=api_key)

    for pdf_path in args.pdf:
        process_pdf(client, pdf_path, out_dir)

    print("\nDone. Open the *_graph_summary.json files to review the emergent "
          "node/edge types before locking in your Neo4j schema.")


# ---------------------------------------------------------------------------
# Optional: vision-based extraction for scanned/photo pages (like the phone
# screenshots you shared). Swap `extract_pages_text` for something that
# calls this per page image if you don't have clean text-native PDFs.
# ---------------------------------------------------------------------------
def extract_pages_via_vision(client: OpenAI, image_path: str, page_num: int, doc_name: str) -> dict:
    import base64

    with open(image_path, "rb") as f:
        b64 = base64.b64encode(f.read()).decode("utf-8")

    user_content = [
        {"type": "text", "text": f"Document: {doc_name}\nPage: {page_num}\n\nExtract graph entities/relationships from this contract page image."},
        {"type": "image_url", "image_url": {"url": f"data:image/jpeg;base64,{b64}"}},
    ]

    resp = client.chat.completions.create(
        model=MODEL,
        temperature=0,
        response_format={"type": "json_object"},
        messages=[
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": user_content},
        ],
    )
    return json.loads(resp.choices[0].message.content)


if __name__ == "__main__":
    main()
